let gameResult = document.getElementById("gameResult");
let userInput = document.getElementById("userInput");

function checkGuess() {

}